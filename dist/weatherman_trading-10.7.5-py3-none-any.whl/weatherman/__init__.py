"""Weatherman temperature-market analytics."""

__version__ = "10.7.5"
